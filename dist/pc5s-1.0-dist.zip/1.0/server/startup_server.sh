nohup java -classpath '.:lib/*' zhuboss.pc2server.sengine.StartSEngine &
tail -f nohup.out